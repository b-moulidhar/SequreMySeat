import Dashboard from "../Dashboard/dashboard";
import Navbar from "../Navbar/navbar";


export default function Home(){
    return(
       <>
            <Navbar/>
            <Dashboard/>
       </>
        
    )
}